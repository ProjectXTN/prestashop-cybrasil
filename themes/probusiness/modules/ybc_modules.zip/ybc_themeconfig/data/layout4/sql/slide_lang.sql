INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('10','_ID_LANG_','New Smart watch series','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec <br /> odio. Praesent libero. Sed cursus ante dapibus diam</p>','Apple watches','Purchase now','#','5c09457b1b2f1bb4c75244bc7aa7ab8166cbcbf3_slider4.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('15','_ID_LANG_','New experiences with Android 7.1','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec<br /> odio. Praesent libero. Sed cursus ante dapibus diam</p>','galaxy tab E','Purchase now','#','6f7a70cf3013d28f66b3166f9b9513c135768df4_slider4-2.jpg');


