INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('10','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('15','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('10','0','1','random','8%','10%','10%','type1','left','left','60%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('15','0','1','random','10%','10%','10%','type2','left','left','60%','','#');


