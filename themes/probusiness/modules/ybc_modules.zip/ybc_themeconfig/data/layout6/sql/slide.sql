INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('12','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('17','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('12','0','1','random','10%','5%','10%','type1','left','left','80%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('17','0','1','random','10%','5%','10%','type3','left','left','60%','','#');


