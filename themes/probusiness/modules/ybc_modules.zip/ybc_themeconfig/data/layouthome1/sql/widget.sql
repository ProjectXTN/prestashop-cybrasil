INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('14','ybcCustom4','1','0','1','1','','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('47','ybcCustom2','1','0','1','1','','fa-tags','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('48','ybcCustom2','1','0','1','1','','fa-wrench','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('49','ybcCustom2','1','0','1','1','','fa-truck','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('51','displayHome','1','1','1','1','banner2.jpg','','#','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('52','displayHome','1','1','1','1','banner3.jpg','','#','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('62','ybcCustom6','1','1','1','1','','','http://demo.etssoft.net/digital/contact-us','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('63','ybcCustom6','1','1','1','1','','','http://demo.etssoft.net/digital/content/1-delivery','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('64','ybcCustom6','1','1','1','1','','','#','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('69','displayHome','1','1','1','1','banner1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('70','ybcCustom3','1','1','1','1','','fa-truck','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('71','ybcCustom3','1','1','1','1','','fa-whatsapp','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('72','ybcCustom3','1','1','1','1','','fa-paypal','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('73','displayLeftColumn','1','0','1','0','ad-banner.jpg','','http://demo.etssoft.net/ebusinessdemo/prices-drop','1');


