INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('1','_ID_LANG_','New generation of digital cameras','<p>Get thhe confident to archive your photographic<br /> vision with canon FX800D</p>','CAnon Fx800D','Purchase Now','#','54760ce9062b460dcebbff8915287f5aa10085fe_slider1.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('2','_ID_LANG_','New lap top Serires','<p>New laptop model from Acer, powerful notebook for<br /> anywhere the jobs take you</p>','Acer Aspire R11','Purchase now','#','074c3d2f0395e11f6fbf0583b1e395804b0b62ff_slider1-2.jpg');


