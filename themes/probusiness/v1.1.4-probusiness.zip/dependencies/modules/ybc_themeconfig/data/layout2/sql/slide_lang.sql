INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('3','_ID_LANG_','New experiences with Android 7.1','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec<br /> odio. Praesent libero. Sed cursus ante dapibus diam</p>','Samsung galaxy tab','Purchase now','#','68651decd0b32065db39a9777b5125ce2a64b8a9_slider2.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('13','_ID_LANG_','New lap top Serires','<p>New laptop model from Acer, powerful notebook for<br /> anywhere the jobs take you</p>','Acer Aspire R11','Purchase now','#','064e304ca8f3ab44775281fa43ea904bce6074a9_slider22.jpg');


